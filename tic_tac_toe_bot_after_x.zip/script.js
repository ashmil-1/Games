// Reinitialize board and state
const board = document.getElementById("board");
const statusText = document.getElementById("status");
let currentPlayer = "X";
let gameActive = true;
let gameState = ["", "", "", "", "", "", "", "", ""];

const winningConditions = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]
];

function handleCellClick(clickedCellIndex) {
  if (gameState[clickedCellIndex] !== "" || !gameActive) return;
  gameState[clickedCellIndex] = currentPlayer;
  renderBoard();
  checkResult();

  const botEnabled = document.getElementById("playWithBot").checked;
  const difficulty = document.getElementById("difficulty").value;

  if (botEnabled && gameActive && currentPlayer === "X") {
    currentPlayer = "O";
    setTimeout(() => {
      botMove(difficulty);
      currentPlayer = "X";
      if (gameActive) statusText.textContent = `Player ${currentPlayer}'s turn`;
    }, 500);
  }
}

function renderBoard() {
  board.innerHTML = "";
  gameState.forEach((cell, index) => {
    const cellDiv = document.createElement("div");
    cellDiv.classList.add("cell");
    cellDiv.textContent = cell;
    cellDiv.addEventListener("click", () => handleCellClick(index));
    board.appendChild(cellDiv);
  });
}

function checkResult() {
  let roundWon = false;
  let winningCombo = [];

  for (let condition of winningConditions) {
    const [a, b, c] = condition;
    if (gameState[a] && gameState[a] === gameState[b] && gameState[a] === gameState[c]) {
      roundWon = true;
      winningCombo = condition;
      break;
    }
  }

  const cells = document.querySelectorAll(".cell");

  if (roundWon) {
    statusText.textContent = `Player ${currentPlayer} wins!`;
    winningCombo.forEach(index => cells[index].classList.add("winner"));
    cells.forEach((cell, i) => {
      if (!winningCombo.includes(i)) cell.classList.add("loser");
    });
    gameActive = false;
    return;
  }

  if (!gameState.includes("")) {
    statusText.textContent = "It's a draw!";
    cells.forEach(cell => cell.classList.add("draw-bg"));
    gameActive = false;
    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";
  statusText.textContent = `Player ${currentPlayer}'s turn`;
}

function resetGame() {
  gameState = ["", "", "", "", "", "", "", "", ""];
  currentPlayer = "X";
  gameActive = true;
  statusText.textContent = `Player ${currentPlayer}'s turn`;
  renderBoard();
}

function newGame() {
  resetGame();
}

resetGame();

function botMove(difficulty) {
  if (!gameActive) return;
  let move;

  if (difficulty === "easy") {
    const emptyCells = gameState.map((val, i) => val === "" ? i : null).filter(i => i !== null);
    move = emptyCells[Math.floor(Math.random() * emptyCells.length)];
  } else if (difficulty === "medium") {
    move = findBestMoveMedium();
  } else {
    move = findBestMoveHard(gameState, "O").index;
  }

  if (move !== undefined && gameState[move] === "") {
    gameState[move] = "O";
    renderBoard();
    checkResult();
  }
}

function findBestMoveMedium() {
  for (let condition of winningConditions) {
    const [a, b, c] = condition;
    const line = [gameState[a], gameState[b], gameState[c]];
    if (line.filter(v => v === "O").length === 2 && line.includes("")) {
      return condition[line.indexOf("")];
    }
    if (line.filter(v => v === "X").length === 2 && line.includes("")) {
      return condition[line.indexOf("")];
    }
  }
  const empty = gameState.map((val, i) => val === "" ? i : null).filter(i => i !== null);
  return empty[Math.floor(Math.random() * empty.length)];
}

function findBestMoveHard(board, player) {
  const availSpots = board.map((val, i) => val === "" ? i : null).filter(i => i !== null);

  if (checkWin(board, "X")) return { score: -10 };
  if (checkWin(board, "O")) return { score: 10 };
  if (availSpots.length === 0) return { score: 0 };

  const moves = [];

  for (let i = 0; i < availSpots.length; i++) {
    let move = {};
    move.index = availSpots[i];
    board[availSpots[i]] = player;

    if (player === "O") {
      let result = findBestMoveHard(board, "X");
      move.score = result.score;
    } else {
      let result = findBestMoveHard(board, "O");
      move.score = result.score;
    }

    board[availSpots[i]] = "";
    moves.push(move);
  }

  let bestMove = 0;
  if (player === "O") {
    let bestScore = -Infinity;
    for (let i = 0; i < moves.length; i++) {
      if (moves[i].score > bestScore) {
        bestScore = moves[i].score;
        bestMove = i;
      }
    }
  } else {
    let bestScore = Infinity;
    for (let i = 0; i < moves.length; i++) {
      if (moves[i].score < bestScore) {
        bestScore = moves[i].score;
        bestMove = i;
      }
    }
  }
  return moves[bestMove];
}

function checkWin(board, player) {
  return winningConditions.some(cond => cond.every(index => board[index] === player));
}
